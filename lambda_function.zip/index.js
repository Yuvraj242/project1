const AWS = require('aws-sdk');
const sharp = require('sharp');

const sourceBucketName = 'sourcebucketgroup1';
const destinationBucketName = 'destinationbucketgroup1';

const s3 = new AWS.S3();

exports.handler = async (event) => {
  const srcKey = event.Records[0].s3.object.key;

  try {
    // Get the image from the source bucket
    const params = {
      Bucket: sourceBucketName,
      Key: srcKey
    };
    const imageObject = await s3.getObject(params).promise();

    // Optimize the image using Sharp library
    const sharpInstance = sharp(imageObject.Body);
    const optimizedImage = await sharpInstance.resize(350).toBuffer();
    // You can specify your desired image dimensions here

    // Upload the optimized image to the destination bucket
    const uploadParams = {
      Bucket: destinationBucketName,
      Key: srcKey,
      Body: optimizedImage
    };
    await s3.putObject(uploadParams).promise();

    return {
      statusCode: 200,
      body: JSON.stringify('Image optimized and stored successfully.')
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify('Error optimizing or storing the image.')
    };
  }
};
